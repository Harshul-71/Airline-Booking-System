package com.airline.util;

public class DBConfig {
    public static final String DB_URL = "jdbc:mysql://localhost:3306/";
    public static final String DATABASE_NAME = "airline_booking";
    public static final String FULL_DB_URL = DB_URL + DATABASE_NAME;
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
}
