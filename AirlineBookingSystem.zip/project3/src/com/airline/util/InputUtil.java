package com.airline.util;

import java.util.Scanner;

public class InputUtil {
    private static Scanner scanner = new Scanner(System.in);

    public static String getString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    public static int getInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("❌ Please enter a valid number.");
            }
        }
    }



    // Enhanced password validation
    public static String getPassword(String prompt) {
        String password;
        do {
            password = getString(prompt);
            if (!validatePassword(password)) {
                continue;
            }
            break;
        } while (true);
        return password;
    }

    public static boolean validatePassword(String password) {
        if (password.length() < 8 || password.length() > 12) {
            System.out.println("❌ Password must be 8-12 characters long.");
            return false;
        }

        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isLowerCase(ch)) hasLower = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if ("@#$%^&+=!".indexOf(ch) >= 0) hasSpecial = true;
        }

        if (!hasUpper) {
            System.out.println("❌ Password must contain uppercase letter.");
            return false;
        }
        if (!hasLower) {
            System.out.println("❌ Password must contain lowercase letter.");
            return false;
        }
        if (!hasDigit) {
            System.out.println("❌ Password must contain digit.");
            return false;
        }
        if (!hasSpecial) {
            System.out.println("❌ Password must contain special character (@#$%^&+=!).");
            return false;
        }
        return true;
    }

    // Name validation
    public static String getName(String prompt) {
        String name;
        do {
            name = getString(prompt);
            if (!validateName(name)) continue;
            break;
        } while (true);
        return name;
    }

    public static boolean validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            System.out.println("❌ Name cannot be empty.");
            return false;
        }

        for (char ch : name.toCharArray()) {
            if (!Character.isLetter(ch) && ch != ' ') {
                System.out.println("❌ Name can only contain letters and spaces.");
                return false;
            }
        }
        return true;
    }

    // Email validation using if-else
    public static String getEmail(String prompt) {
        String email;
        do {
            email = getString(prompt);
            if (!validateEmail(email)) continue;
            break;
        } while (true);
        return email;
    }

    public static boolean validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            System.out.println("❌ Email cannot be empty.");
            return false;
        }

        int atPos = email.indexOf('@');
        int dotPos = email.lastIndexOf('.');

        if (atPos < 1 || dotPos < atPos + 2 || dotPos >= email.length() - 1) {
            System.out.println("❌ Invalid email format. Use: user@domain.com");
            return false;
        }

        if (email.contains(" ") || email.contains("..") || 
            email.indexOf('@') != email.lastIndexOf('@')) {
            System.out.println("❌ Invalid email format.");
            return false;
        }

        return true;
    }

    // Phone validation
    public static String getPhone(String prompt) {
        String phone;
        do {
            phone = getString(prompt);
            if (!validatePhone(phone)) continue;
            break;
        } while (true);
        return phone;
    }

    public static boolean validatePhone(String phone) {
        if (phone == null || phone.length() != 10) {
            System.out.println("❌ Phone must be exactly 10 digits.");
            return false;
        }

        for (char ch : phone.toCharArray()) {
            if (!Character.isDigit(ch)) {
                System.out.println("❌ Phone must contain only digits.");
                return false;
            }
        }
        return true;
    }

    public static void closeScanner() {
        scanner.close();
    }
}
