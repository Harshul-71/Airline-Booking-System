package com.airline.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DBConfig.DRIVER);
            return DriverManager.getConnection(DBConfig.FULL_DB_URL, DBConfig.USERNAME, DBConfig.PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL Driver not found", e);
        }
    }

    public static Connection getConnectionForSetup() throws SQLException {
        try {
            Class.forName(DBConfig.DRIVER);
            return DriverManager.getConnection(DBConfig.DB_URL, DBConfig.USERNAME, DBConfig.PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL Driver not found", e);
        }
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
}
