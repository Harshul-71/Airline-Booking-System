package com.airline.util;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class SchemaInitializer {

    public static void initialize() {
        try {
            createDatabase();
            createTables();
            createProcedures();
            createTriggers();
            insertSampleData();
            System.out.println("✅ Database initialized successfully!");
        } catch (SQLException e) {
            System.err.println("❌ Database error: " + e.getMessage());
        }
    }

    private static void createDatabase() throws SQLException {
        Connection conn = DB.getConnectionForSetup();
        Statement stmt = conn.createStatement();
        stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DBConfig.DATABASE_NAME);
        stmt.close();
        conn.close();
    }

    private static void createTables() throws SQLException {
        Connection conn = DB.getConnection();
        Statement stmt = conn.createStatement();

        // Admin table
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS admin (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "username VARCHAR(50) UNIQUE NOT NULL," +
            "password VARCHAR(100) NOT NULL)");

        // Customer table
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS customer (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "name VARCHAR(100) NOT NULL," +
            "email VARCHAR(100) UNIQUE NOT NULL," +
            "phone VARCHAR(15) NOT NULL," +
            "password VARCHAR(100) NOT NULL)");

        // Destination table
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS destination (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "name VARCHAR(100) NOT NULL," +
            "type ENUM('DOMESTIC', 'INTERNATIONAL') NOT NULL)");

        // Flight table with foreign keys
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS flight (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "code VARCHAR(10) UNIQUE NOT NULL," +
            "destination_id INT NOT NULL," +
            "departure_time DATETIME NOT NULL," +
            "arrival_time DATETIME NOT NULL," +
            "capacity INT NOT NULL," +
            "base_price DECIMAL(10,2) NOT NULL," +
            "flight_type ENUM('DOMESTIC', 'INTERNATIONAL') NOT NULL," +
            "from_city VARCHAR(100) NOT NULL," +
            "FOREIGN KEY (destination_id) REFERENCES destination(id) ON DELETE CASCADE)");

        // Domestic flight table
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS domestic_flight (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "flight_id INT NOT NULL," +
            "FOREIGN KEY (flight_id) REFERENCES flight(id) ON DELETE CASCADE)");

        // International flight table
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS international_flight (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "flight_id INT NOT NULL," +
            "FOREIGN KEY (flight_id) REFERENCES flight(id) ON DELETE CASCADE)");

        // Booking table with foreign keys
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS booking (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "customer_id INT NOT NULL," +
            "flight_id INT NOT NULL," +
            "passenger_name VARCHAR(100) NOT NULL," +
            "seat_no VARCHAR(10) NOT NULL," +
            "status ENUM('CONFIRMED', 'CANCELLED') DEFAULT 'CONFIRMED'," +
            "booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE," +
            "FOREIGN KEY (flight_id) REFERENCES flight(id) ON DELETE CASCADE)");

        stmt.close();
        conn.close();
    }

    private static void createProcedures() throws SQLException {
        Connection conn = DB.getConnection();
        Statement stmt = conn.createStatement();

        // Procedure to get available seats
        String getSeatsProc = 
            "CREATE PROCEDURE IF NOT EXISTS GetAvailableSeats(IN flight_id INT, OUT available INT) " +
            "BEGIN " +
            "    SELECT (f.capacity - COALESCE(COUNT(b.id), 0)) INTO available " +
            "    FROM flight f LEFT JOIN booking b ON f.id = b.flight_id AND b.status = 'CONFIRMED' " +
            "    WHERE f.id = flight_id GROUP BY f.id, f.capacity; " +
            "END";

        // Procedure to cancel booking
        String cancelProc = 
            "CREATE PROCEDURE IF NOT EXISTS CancelBooking(IN booking_id INT, IN cust_id INT, OUT result VARCHAR(255)) " +
            "BEGIN " +
            "    DECLARE cnt INT DEFAULT 0; " +
            "    SELECT COUNT(*) INTO cnt FROM booking WHERE id = booking_id AND customer_id = cust_id AND status = 'CONFIRMED'; " +
            "    IF cnt > 0 THEN " +
            "        UPDATE booking SET status = 'CANCELLED' WHERE id = booking_id; " +
            "        SET result = 'Booking cancelled successfully'; " +
            "    ELSE " +
            "        SET result = 'Invalid booking or already cancelled'; " +
            "    END IF; " +
            "END";

        try {
            stmt.executeUpdate("DROP PROCEDURE IF EXISTS GetAvailableSeats");
            stmt.executeUpdate(getSeatsProc);
            stmt.executeUpdate("DROP PROCEDURE IF EXISTS CancelBooking");
            stmt.executeUpdate(cancelProc);
        } catch (SQLException e) {
            System.err.println("Error creating procedures: " + e.getMessage());
        }

        stmt.close();
        conn.close();
    }

    private static void createTriggers() throws SQLException {
        Connection conn = DB.getConnection();
        Statement stmt = conn.createStatement();

        // Trigger for booking validation
        String bookingTrigger = 
            "CREATE TRIGGER IF NOT EXISTS validate_booking " +
            "BEFORE INSERT ON booking FOR EACH ROW " +
            "BEGIN " +
            "    DECLARE available INT DEFAULT 0; " +
            "    DECLARE customer_bookings INT DEFAULT 0; " +
            "    SELECT (f.capacity - COALESCE(COUNT(b.id), 0)) INTO available " +
            "    FROM flight f LEFT JOIN booking b ON f.id = b.flight_id AND b.status = 'CONFIRMED' " +
            "    WHERE f.id = NEW.flight_id GROUP BY f.id, f.capacity; " +
            "    SELECT COUNT(*) INTO customer_bookings FROM booking " +
            "    WHERE customer_id = NEW.customer_id AND flight_id = NEW.flight_id AND status = 'CONFIRMED'; " +
            "    IF available <= 0 THEN " +
            "        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No seats available'; " +
            "    END IF; " +
            "    IF customer_bookings >= 4 THEN " +
            "        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Max 4 tickets per customer per flight'; " +
            "    END IF; " +
            "END";

        // Trigger for flight type insertion
        String flightTrigger = 
            "CREATE TRIGGER IF NOT EXISTS insert_flight_type " +
            "AFTER INSERT ON flight FOR EACH ROW " +
            "BEGIN " +
            "    IF NEW.flight_type = 'DOMESTIC' THEN " +
            "        INSERT INTO domestic_flight (flight_id) VALUES (NEW.id); " +
            "    ELSE " +
            "        INSERT INTO international_flight (flight_id) VALUES (NEW.id); " +
            "    END IF; " +
            "END";

        try {
            stmt.executeUpdate("DROP TRIGGER IF EXISTS validate_booking");
            stmt.executeUpdate(bookingTrigger);
            stmt.executeUpdate("DROP TRIGGER IF EXISTS insert_flight_type");
            stmt.executeUpdate(flightTrigger);
        } catch (SQLException e) {
            System.err.println("Error creating triggers: " + e.getMessage());
        }

        stmt.close();
        conn.close();
    }

    private static void insertSampleData() throws SQLException {
        Connection conn = DB.getConnection();
        Statement stmt = conn.createStatement();

        // Insert admin
        stmt.executeUpdate("INSERT IGNORE INTO admin (username, password) VALUES ('admin', 'Admin@123')");

        // Insert domestic destinations
        String[] domestic = {"Ahmedabad", "Mumbai", "Surat", "Bangalore", "Hyderabad", "Chennai", "Pune", "Odisha"};
        for (String dest : domestic) {
            stmt.executeUpdate("INSERT IGNORE INTO destination (name, type) VALUES ('" + dest + "', 'DOMESTIC')");
        }

        // Insert international destinations
        String[] international = {"Singapore", "Thailand", "Bangkok", "Las Vegas", "San Francisco", "Tokyo"};
        for (String dest : international) {
            stmt.executeUpdate("INSERT IGNORE INTO destination (name, type) VALUES ('" + dest + "', 'INTERNATIONAL')");
        }

        // Insert sample customers
        stmt.executeUpdate("INSERT IGNORE INTO customer (name, email, phone, password) VALUES " +
            "('Rajesh Kumar', 'rajesh@email.com', '9876543210', 'Rajesh@123'), " +
            "('Priya Sharma', 'priya@email.com', '9876543211', 'Priya@123'), " +
            "('Amit Patel', 'amit@email.com', '9876543212', 'Amit@123'), " +
            "('Sneha Gupta', 'sneha@email.com', '9876543213', 'Sneha@123'), " +
            "('Vikram Singh', 'vikram@email.com', '9876543214', 'Vikram@123')");

        // Insert domestic flights
        stmt.executeUpdate("INSERT IGNORE INTO flight (code, destination_id, departure_time, arrival_time, capacity, base_price, flight_type, from_city) VALUES " +
            "('AI101', 1, '2025-09-01 08:00:00', '2025-09-01 10:30:00', 180, 5500.00, 'DOMESTIC', 'Mumbai'), " +
            "('AI102', 2, '2025-09-01 14:00:00', '2025-09-01 16:00:00', 150, 4500.00, 'DOMESTIC', 'Ahmedabad'), " +
            "('AI103', 4, '2025-09-02 09:00:00', '2025-09-02 11:30:00', 200, 6500.00, 'DOMESTIC', 'Mumbai'), " +
            "('AI104', 5, '2025-09-02 15:00:00', '2025-09-02 17:30:00', 160, 7000.00, 'DOMESTIC', 'Chennai'), " +
            "('AI105', 6, '2025-09-03 07:00:00', '2025-09-03 09:30:00', 180, 6800.00, 'DOMESTIC', 'Bangalore')");

        // Insert international flights
        stmt.executeUpdate("INSERT IGNORE INTO flight (code, destination_id, departure_time, arrival_time, capacity, base_price, flight_type, from_city) VALUES " +
            "('INT201', 9, '2025-09-05 22:00:00', '2025-09-06 05:30:00', 300, 35000.00, 'INTERNATIONAL', 'Mumbai'), " +
            "('INT202', 10, '2025-09-06 01:00:00', '2025-09-06 08:00:00', 280, 32000.00, 'INTERNATIONAL', 'Delhi'), " +
            "('INT203', 11, '2025-09-07 23:30:00', '2025-09-08 06:00:00', 250, 33000.00, 'INTERNATIONAL', 'Bangalore'), " +
            "('INT204', 12, '2025-09-10 20:00:00', '2025-09-11 14:00:00', 350, 85000.00, 'INTERNATIONAL', 'Mumbai'), " +
            "('INT205', 13, '2025-09-12 21:00:00', '2025-09-13 12:00:00', 280, 75000.00, 'INTERNATIONAL', 'Delhi')");

        // Insert sample bookings
        stmt.executeUpdate("INSERT IGNORE INTO booking (customer_id, flight_id, passenger_name, seat_no, status) VALUES " +
            "(1, 1, 'Rajesh Kumar', 'A1', 'CONFIRMED'), " +
            "(2, 2, 'Priya Sharma', 'B1', 'CONFIRMED'), " +
            "(3, 3, 'Amit Patel', 'C1', 'CONFIRMED'), " +
            "(4, 6, 'Sneha Gupta', 'A2', 'CONFIRMED'), " +
            "(5, 7, 'Vikram Singh', 'B2', 'CONFIRMED')");

        stmt.close();
        conn.close();
    }
}
