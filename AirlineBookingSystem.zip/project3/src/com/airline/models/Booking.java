package com.airline.models;

import java.time.LocalDateTime;

public class Booking {
    private int id;
    private int customerId;
    private int flightId;
    private String passengerName;
    private String seatNo;
    private String status;
    private LocalDateTime bookingDate;

    // Additional fields for display
    private String flightCode;
    private String destinationName;
    private LocalDateTime departureTime;
    private double price;

    public Booking() {}

    public Booking(int customerId, int flightId, String passengerName, String seatNo) {
        this.customerId = customerId;
        this.flightId = flightId;
        this.passengerName = passengerName;
        this.seatNo = seatNo;
        this.status = "CONFIRMED";
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }
    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) { this.passengerName = passengerName; }
    public String getSeatNo() { return seatNo; }
    public void setSeatNo(String seatNo) { this.seatNo = seatNo; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDateTime bookingDate) { this.bookingDate = bookingDate; }
    public String getFlightCode() { return flightCode; }
    public void setFlightCode(String flightCode) { this.flightCode = flightCode; }
    public String getDestinationName() { return destinationName; }
    public void setDestinationName(String destinationName) { this.destinationName = destinationName; }
    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime departureTime) { this.departureTime = departureTime; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
}
