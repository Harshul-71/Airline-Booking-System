package com.airline;

import com.airline.models.Admin;
import com.airline.models.Customer;
import com.airline.services.AdminService;
import com.airline.services.CustomerService;
import com.airline.util.InputUtil;
import com.airline.util.SchemaInitializer;

public class Main {
    private static AdminService adminService = new AdminService();
    private static CustomerService customerService = new CustomerService();

    public static void main(String[] args) {
        System.out.println("===========================================");
        System.out.println("    ✈️ AIRLINE BOOKING SYSTEM ✈️");
        System.out.println("===========================================");

        // Initialize database with procedures and triggers
        System.out.println("🔄 Initializing database...");
        SchemaInitializer.initialize();

        boolean running = true;
        while (running) {
            try {
                showMainMenu();
                int choice = InputUtil.getInt("");

                switch (choice) {
                    case 1: handleAdminFlow(); break;
                    case 2: handleCustomerFlow(); break;
                    case 3: 
                        System.out.println("\n✈️ Thank you for using Airline Booking System!");
                        running = false;
                        break;
                    default: System.out.println("❌ Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.err.println("❌ Error: " + e.getMessage());
                System.out.println("Please try again.");
            }
        }

        InputUtil.closeScanner();
        System.exit(0);
    }

    private static void showMainMenu() {
        System.out.println("\n┌────────────────────────────┐");
        System.out.println("│        MAIN MENU            │");
        System.out.println("├─────────────────────────────┤");
        System.out.println("│ 1. 👨‍💼 Admin Login           │");
        System.out.println("│ 2. 🧑‍🤝‍🧑 Customer Portal       │");
        System.out.println("│ 3. 🚪 Exit System           │");
        System.out.println("└─────────────────────────────┘");
        System.out.print("Enter your choice (1-3): ");
    }

    private static void handleAdminFlow() {
        System.out.println("\n👨‍💼 === ADMIN PORTAL ===");

        String username = InputUtil.getString("Enter admin username: ");
        String password = InputUtil.getString("Enter admin password: ");

        Admin admin = adminService.login(username, password);

        if (admin == null) {
            System.out.println("❌ Invalid admin credentials!");
            return;
        }

        System.out.println("✅ Welcome, Admin " + admin.getUsername() + "!");

        boolean adminLoggedIn = true;
        while (adminLoggedIn) {
            try {
                adminService.showAdminMenu();
                int choice = InputUtil.getInt("");

                switch (choice) {
                    case 1: adminService.addDestination(); break;
                    case 2: adminService.viewAllDestinations(); break;
                    case 3: adminService.addFlight(); break;
                    case 4: adminService.viewAllFlights(); break;
                    case 5: adminService.viewAllBookings(); break;
                    case 6: 
                        System.out.println("✅ Admin logged out successfully!");
                        adminLoggedIn = false;
                        break;
                    default: System.out.println("❌ Invalid choice!");
                }
            } catch (Exception e) {
                System.err.println("❌ Error: " + e.getMessage());
            }
        }
    }

    private static void handleCustomerFlow() {
        System.out.println("\n🧑‍🤝‍🧑 === CUSTOMER PORTAL ===");

        boolean customerPortal = true;
        Customer loggedInCustomer = null;

        while (customerPortal) {
            try {
                if (loggedInCustomer == null) {
                    showCustomerAuthMenu();
                    int choice = InputUtil.getInt("");

                    switch (choice) {
                        case 1: loggedInCustomer = customerService.login(); break;
                        case 2: 
                            Customer registered = customerService.register();
                            if (registered != null) {
                                System.out.println("\n🔑 Please login with your credentials:");
                                loggedInCustomer = customerService.login();
                            }
                            break;
                        case 3: customerPortal = false; break;
                        default: System.out.println("❌ Invalid choice!");
                    }
                } else {
                    customerService.showCustomerMenu();
                    int choice = InputUtil.getInt("");

                    switch (choice) {
                        case 1: customerService.searchAndBookFlights(loggedInCustomer); break;
                        case 2: customerService.viewMyBookings(loggedInCustomer); break;
                        case 3: customerService.cancelBooking(loggedInCustomer); break;
                        case 4: customerService.downloadTicket(loggedInCustomer); break;
                        case 5: 
                            System.out.println("✅ Logged out successfully!");
                            loggedInCustomer = null;
                            break;
                        default: System.out.println("❌ Invalid choice!");
                    }
                }
            } catch (Exception e) {
                System.err.println("❌ Error: " + e.getMessage());
            }
        }
    }

    private static void showCustomerAuthMenu() {
        System.out.println("\n┌─────────────────────────────┐");
        System.out.println("│   CUSTOMER AUTHENTICATION  │");
        System.out.println("├─────────────────────────────┤");
        System.out.println("│ 1. 🔑 Login                │");
        System.out.println("│ 2. 📝 Register             │");
        System.out.println("│ 3. ⬅️  Back                │");
        System.out.println("└─────────────────────────────┘");
        System.out.print("Enter choice (1-3): ");
    }
}
