package com.airline.services;

import com.airline.dao.*;
import com.airline.models.*;
import com.airline.util.InputUtil;
import java.sql.SQLException;
import java.util.List;
import java.time.format.DateTimeFormatter;

public class AdminService {
    private AdminDAO adminDAO = new AdminDAO();
    private DestinationDAO destDAO = new DestinationDAO();
    private FlightDAO flightDAO = new FlightDAO();
    private BookingDAO bookingDAO = new BookingDAO();

    public Admin login(String username, String password) {
        try {
            return adminDAO.login(username, password);
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    public void showAdminMenu() {
        System.out.println("\n┌─────────────────────────────┐");
        System.out.println("│        ADMIN MENU           │");
        System.out.println("├─────────────────────────────┤");
        System.out.println("│ 1. 📍 Add Destination      │");
        System.out.println("│ 2. 🗺️  View Destinations    │");
        System.out.println("│ 3. ✈️  Add Flight           │");
        System.out.println("│ 4. 🛫 View All Flights     │");
        System.out.println("│ 5. 📋 View All Bookings    │");
        System.out.println("│ 6. 🚪 Logout               │");
        System.out.println("└─────────────────────────────┘");
        System.out.print("Enter choice (1-6): ");
    }

    public void addDestination() {
        System.out.println("\n📍 === ADD DESTINATION ===");

        String name = InputUtil.getName("Destination name: ");

        System.out.println("\nSelect type:");
        System.out.println("1. Domestic");
        System.out.println("2. International");
        int choice = InputUtil.getInt("Choice (1-2): ");

        String type = (choice == 1) ? "DOMESTIC" : "INTERNATIONAL";

        try {
            Destination dest = new Destination(name, type);
            if (destDAO.addDestination(dest)) {
                System.out.println("✅ Destination added successfully!");
            } else {
                System.out.println("❌ Failed to add destination!");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    public void viewAllDestinations() {
        System.out.println("\n🗺️  === ALL DESTINATIONS ===");

        try {
            List<Destination> destinations = destDAO.getAllDestinations();
            if (destinations.isEmpty()) {
                System.out.println("No destinations found!");
                return;
            }

            System.out.println("\n🏠 DOMESTIC DESTINATIONS:");
            System.out.println("─────────────────────────");
            destinations.stream()
                .filter(d -> "DOMESTIC".equals(d.getType()))
                .forEach(d -> System.out.println(d.getId() + ". " + d.getName()));

            System.out.println("\n🌍 INTERNATIONAL DESTINATIONS:");
            System.out.println("──────────────────────────────");
            destinations.stream()
                .filter(d -> "INTERNATIONAL".equals(d.getType()))
                .forEach(d -> System.out.println(d.getId() + ". " + d.getName()));

        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    public void addFlight() {
        System.out.println("\n✈️  === ADD FLIGHT ===");
        System.out.println("Feature coming soon!");
    }

    public void viewAllFlights() {
        System.out.println("\n🛫 === ALL FLIGHTS ===");

        try {
            List<Flight> flights = flightDAO.getAllFlights();
            if (flights.isEmpty()) {
                System.out.println("No flights found!");
                return;
            }

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            System.out.println("\n🏠 DOMESTIC FLIGHTS:");
            System.out.println("────────────────────");
            flights.stream()
                .filter(f -> "DOMESTIC".equals(f.getFlightType()))
                .forEach(f -> {
                    System.out.printf("✈️  %s | %s → %s | ₹%.2f\n", 
                        f.getCode(), f.getFromCity(), f.getDestinationName(), f.getBasePrice());
                    System.out.printf("   Departure: %s | Capacity: %d\n\n",
                        f.getDepartureTime().format(formatter), f.getCapacity());
                });

            System.out.println("🌍 INTERNATIONAL FLIGHTS:");
            System.out.println("─────────────────────────");
            flights.stream()
                .filter(f -> "INTERNATIONAL".equals(f.getFlightType()))
                .forEach(f -> {
                    System.out.printf("✈️  %s | %s → %s | ₹%.2f\n", 
                        f.getCode(), f.getFromCity(), f.getDestinationName(), f.getBasePrice());
                    System.out.printf("   Departure: %s | Capacity: %d\n\n",
                        f.getDepartureTime().format(formatter), f.getCapacity());
                });

        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    public void viewAllBookings() {
        System.out.println("\n📋 === ALL BOOKINGS ===");

        try {
            List<Booking> bookings = bookingDAO.getAllBookings();
            if (bookings.isEmpty()) {
                System.out.println("No bookings found!");
                return;
            }

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            for (Booking booking : bookings) {
                System.out.printf("🎫 ID:%d | %s | %s → %s | Seat:%s | %s\n",
                    booking.getId(), booking.getPassengerName(), 
                    booking.getFlightCode(), booking.getDestinationName(),
                    booking.getSeatNo(), booking.getStatus());
                System.out.printf("   Customer ID:%d | Departure: %s | ₹%.2f\n\n",
                    booking.getCustomerId(), 
                    booking.getDepartureTime().format(formatter), 
                    booking.getPrice());
            }

        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }
}
