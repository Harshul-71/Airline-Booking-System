package com.airline.services;

import com.airline.dao.*;
import com.airline.models.*;
import com.airline.util.InputUtil;
import java.sql.SQLException;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;

public class CustomerService {
    private CustomerDAO customerDAO = new CustomerDAO();
    private DestinationDAO destDAO = new DestinationDAO();
    private FlightDAO flightDAO = new FlightDAO();
    private BookingDAO bookingDAO = new BookingDAO();

    public Customer register() {
        System.out.println("\n📝 === CUSTOMER REGISTRATION ===");

        String name = InputUtil.getName("Full name: ");
        String email = InputUtil.getEmail("Email: ");

        try {
            if (customerDAO.isEmailExists(email)) {
                System.out.println("❌ Email already exists!");
                return null;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
            return null;
        }

        String phone = InputUtil.getPhone("Phone (10 digits): ");
        String password = InputUtil.getPassword("Password (8-12 chars, mixed case, digit, special): ");

        Customer customer = new Customer(name, email, phone, password);

        try {
            if (customerDAO.register(customer)) {
                System.out.println("✅ Registration successful!");
                return customer;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
        return null;
    }

    public Customer login() {
        System.out.println("\n🔑 === CUSTOMER LOGIN ===");

        String email = InputUtil.getString("Email: ");
        String password = InputUtil.getString("Password: ");

        try {
            Customer customer = customerDAO.login(email, password);
            if (customer != null) {
                System.out.println("✅ Welcome, " + customer.getName() + "!");
            } else {
                System.out.println("❌ Invalid credentials!");
            }
            return customer;
        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
            return null;
        }
    }

    public void showCustomerMenu() {
        System.out.println("\n┌─────────────────────────────┐");
        System.out.println("│      CUSTOMER MENU          │");
        System.out.println("├─────────────────────────────┤");
        System.out.println("│ 1. 🔍 Search & Book Flights│");
        System.out.println("│ 2. 📋 View My Bookings     │");
        System.out.println("│ 3. ❌ Cancel Booking       │");
        System.out.println("│ 4. 📄 Download Ticket      │");
        System.out.println("│ 5. 🚪 Logout               │");
        System.out.println("└─────────────────────────────┘");
        System.out.print("Enter choice (1-5): ");
    }

    public void searchAndBookFlights(Customer customer) {
        System.out.println("\n🔍 === SEARCH & BOOK FLIGHTS ===");

        System.out.println("\nSelect flight type:");
        System.out.println("1. 🏠 Domestic");
        System.out.println("2. 🌍 International");
        int choice = InputUtil.getInt("Choice (1-2): ");

        String type = (choice == 1) ? "DOMESTIC" : "INTERNATIONAL";

        try {
            List<Destination> destinations = destDAO.getDestinationsByType(type);
            if (destinations.isEmpty()) {
                System.out.println("❌ No destinations available!");
                return;
            }

            System.out.println("\nAvailable " + type.toLowerCase() + " destinations:");
            for (int i = 0; i < destinations.size(); i++) {
                System.out.println((i + 1) + ". " + destinations.get(i).getName());
            }

            int destChoice = InputUtil.getInt("Select destination (1-" + destinations.size() + "): ");
            if (destChoice < 1 || destChoice > destinations.size()) {
                System.out.println("❌ Invalid choice!");
                return;
            }

            String destName = destinations.get(destChoice - 1).getName();
            String fromCity = InputUtil.getString("From where are you boarding the flight? ");

            List<Flight> flights = flightDAO.searchFlights(fromCity, destName, type);
            if (flights.isEmpty()) {
                System.out.println("❌ No flights found!");
                return;
            }

            displayFlights(flights);

            int flightId = InputUtil.getInt("Select flight ID: ");
            Flight selectedFlight = flights.stream()
                .filter(f -> f.getId() == flightId)
                .findFirst().orElse(null);

            if (selectedFlight == null) {
                System.out.println("❌ Invalid flight selection!");
                return;
            }

            int availableSeats = flightDAO.getAvailableSeats(flightId);
            int existingBookings = bookingDAO.getCustomerBookingCount(customer.getId(), flightId);
            int maxTickets = Math.min(4 - existingBookings, availableSeats);

            if (maxTickets <= 0) {
                System.out.println("❌ No seats available or max bookings reached!");
                return;
            }

            int numTickets = InputUtil.getInt("Number of tickets (max " + maxTickets + "): ");
            if (numTickets > maxTickets || numTickets < 1) {
                System.out.println("❌ Invalid number of tickets!");
                return;
            }

            List<String> usedSeats = bookingDAO.getUsedSeats(flightId);

            for (int i = 1; i <= numTickets; i++) {
                String passengerName = InputUtil.getName("Passenger " + i + " name: ");
                String seat = generateSeat(i, usedSeats.size());

                Booking booking = new Booking(customer.getId(), flightId, passengerName, seat);
                if (bookingDAO.bookTicket(booking)) {
                    System.out.println("✅ Booked: " + passengerName + " - Seat " + seat);
                    usedSeats.add(seat);
                }
            }

            System.out.printf("\n💰 Total Amount: ₹%.2f\n", selectedFlight.getBasePrice() * numTickets);

        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    private void displayFlights(List<Flight> flights) {
        System.out.println("\n✈️  Available Flights:");
        System.out.println("═════════════════════");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        for (Flight flight : flights) {
            System.out.printf("🛫 ID:%d | %s | %s → %s\n", 
                flight.getId(), flight.getCode(), flight.getFromCity(), flight.getDestinationName());
            System.out.printf("   Departure: %s | Price: ₹%.2f\n",
                flight.getDepartureTime().format(formatter), flight.getBasePrice());
            try {
                int available = flightDAO.getAvailableSeats(flight.getId());
                System.out.printf("   Available Seats: %d\n", available);
            } catch (SQLException e) {
                System.out.println("   Available Seats: Unknown");
            }
            System.out.println("   ─────────────────────");
        }
    }

    private String generateSeat(int ticketNum, int usedCount) {
        String[] rows = {"A", "B", "C", "D", "E", "F"};
        int seatNum = usedCount + ticketNum;
        return rows[(seatNum - 1) % rows.length] + ((seatNum - 1) / rows.length + 1);
    }

    public void viewMyBookings(Customer customer) {
        System.out.println("\n📋 === MY BOOKINGS ===");

        try {
            List<Booking> bookings = bookingDAO.getCustomerBookings(customer.getId());
            if (bookings.isEmpty()) {
                System.out.println("No bookings found!");
                return;
            }

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            for (Booking booking : bookings) {
                System.out.printf("🎫 ID:%d | %s | %s → %s\n",
                    booking.getId(), booking.getPassengerName(), 
                    booking.getFlightCode(), booking.getDestinationName());
                System.out.printf("   Seat:%s | Status:%s | ₹%.2f\n",
                    booking.getSeatNo(), booking.getStatus(), booking.getPrice());
                System.out.printf("   Departure: %s\n",
                    booking.getDepartureTime().format(formatter));
                System.out.println("   ─────────────────────");
            }

        } catch (SQLException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    public void downloadTicket(Customer customer) {
        System.out.println("\n📄 === DOWNLOAD TICKET ===");

        try {
            List<Booking> bookings = bookingDAO.getCustomerBookings(customer.getId());
            if (bookings.isEmpty()) {
                System.out.println("❌ No bookings to download!");
                return;
            }

            System.out.println("\nYour bookings:");
            for (Booking b : bookings) {
                System.out.printf("ID:%d | %s | %s | Seat:%s | %s\n",
                    b.getId(), b.getPassengerName(), b.getFlightCode(), 
                    b.getSeatNo(), b.getStatus());
            }

            int bookingId = InputUtil.getInt("Enter booking ID: ");

            Booking selected = bookings.stream()
                .filter(b -> b.getId() == bookingId)
                .findFirst().orElse(null);

            if (selected == null) {
                System.out.println("❌ Invalid booking ID!");
                return;
            }

            // Generate ticket content
            StringBuilder ticket = new StringBuilder();
            ticket.append("═══════════════════════════════════════\n");
            ticket.append("           ✈️  AIRLINE TICKET ✈️          \n");
            ticket.append("═══════════════════════════════════════\n");
            ticket.append("Booking ID: ").append(selected.getId()).append("\n");
            ticket.append("Passenger: ").append(selected.getPassengerName()).append("\n");
            ticket.append("Flight: ").append(selected.getFlightCode()).append("\n");
            ticket.append("Destination: ").append(selected.getDestinationName()).append("\n");
            ticket.append("Seat: ").append(selected.getSeatNo()).append("\n");
            ticket.append("Departure: ").append(selected.getDepartureTime()).append("\n");
            ticket.append("Price: ₹").append(selected.getPrice()).append("\n");
            ticket.append("Status: ").append(selected.getStatus()).append("\n");
            ticket.append("Booking Date: ").append(selected.getBookingDate()).append("\n");
            ticket.append("═══════════════════════════════════════\n");
            ticket.append("Thank you for choosing our airline!\n");
            ticket.append("Safe travels! ✈️\n");
            ticket.append("═══════════════════════════════════════\n");

            String filename = "ticket_" + bookingId + ".txt";
            try (FileWriter writer = new FileWriter(filename)) {
                writer.write(ticket.toString());
            }

            System.out.println("✅ Ticket downloaded: " + filename);

        } catch (SQLException | IOException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    public void cancelBooking(Customer customer) {
        System.out.println("\n❌ === CANCEL BOOKING ===");

        viewMyBookings(customer);

        int bookingId = InputUtil.getInt("Enter booking ID to cancel: ");
        String confirm = InputUtil.getString("Confirm cancellation (yes/no): ");

        if ("yes".equalsIgnoreCase(confirm)) {
            try {
                if (bookingDAO.cancelBooking(bookingId, customer.getId())) {
                    System.out.println("✅ Booking cancelled successfully!");
                } else {
                    System.out.println("❌ Cancellation failed!");
                }
            } catch (SQLException e) {
                System.err.println("❌ Error: " + e.getMessage());
            }
        }
    }
}
