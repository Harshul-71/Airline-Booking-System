package com.airline.dao;

import com.airline.models.Flight;
import com.airline.util.DB;
import java.sql.*;
import java.util.*;
import java.time.LocalDateTime;

public class FlightDAO {

    public List<Flight> searchFlights(String fromCity, String destName, String type) throws SQLException {
        StringBuilder sql = new StringBuilder(
            "SELECT f.*, d.name as destination_name FROM flight f " +
            "JOIN destination d ON f.destination_id = d.id WHERE 1=1");

        List<String> params = new ArrayList<>();

        if (fromCity != null && !fromCity.trim().isEmpty()) {
            sql.append(" AND f.from_city LIKE ?");
            params.add("%" + fromCity + "%");
        }
        if (destName != null && !destName.trim().isEmpty()) {
            sql.append(" AND d.name LIKE ?");
            params.add("%" + destName + "%");
        }
        if (type != null && !type.trim().isEmpty()) {
            sql.append(" AND f.flight_type = ?");
            params.add(type);
        }

        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql.toString());

        for (int i = 0; i < params.size(); i++) {
            stmt.setString(i + 1, params.get(i));
        }

        ResultSet rs = stmt.executeQuery();
        List<Flight> flights = new ArrayList<>();

        while (rs.next()) {
            Flight flight = createFlightFromResultSet(rs);
            flights.add(flight);
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return flights;
    }

    public int getAvailableSeats(int flightId) throws SQLException {
        String sql = "SELECT (f.capacity - COALESCE(COUNT(b.id), 0)) as available " +
                    "FROM flight f LEFT JOIN booking b ON f.id = b.flight_id AND b.status = 'CONFIRMED' " +
                    "WHERE f.id = ? GROUP BY f.id, f.capacity";

        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, flightId);

        ResultSet rs = stmt.executeQuery();
        int available = 0;

        if (rs.next()) {
            available = rs.getInt("available");
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return available;
    }

    public List<Flight> getAllFlights() throws SQLException {
        String sql = "SELECT f.*, d.name as destination_name FROM flight f " +
                    "JOIN destination d ON f.destination_id = d.id ORDER BY f.departure_time";

        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        ResultSet rs = stmt.executeQuery();
        List<Flight> flights = new ArrayList<>();

        while (rs.next()) {
            flights.add(createFlightFromResultSet(rs));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return flights;
    }

    private Flight createFlightFromResultSet(ResultSet rs) throws SQLException {
        Flight flight = new Flight();
        flight.setId(rs.getInt("id"));
        flight.setCode(rs.getString("code"));
        flight.setDestinationId(rs.getInt("destination_id"));
        flight.setDestinationName(rs.getString("destination_name"));
        flight.setDepartureTime(rs.getTimestamp("departure_time").toLocalDateTime());
        flight.setArrivalTime(rs.getTimestamp("arrival_time").toLocalDateTime());
        flight.setCapacity(rs.getInt("capacity"));
        flight.setBasePrice(rs.getDouble("base_price"));
        flight.setFlightType(rs.getString("flight_type"));
        flight.setFromCity(rs.getString("from_city"));
        return flight;
    }
}
