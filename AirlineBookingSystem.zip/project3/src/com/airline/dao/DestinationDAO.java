package com.airline.dao;

import com.airline.models.Destination;
import com.airline.util.DB;
import java.sql.*;
import java.util.*;

public class DestinationDAO {

    public boolean addDestination(Destination destination) throws SQLException {
        String sql = "INSERT INTO destination (name, type) VALUES (?, ?)";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, destination.getName());
        stmt.setString(2, destination.getType());

        int result = stmt.executeUpdate();

        stmt.close();
        DB.closeConnection(conn);
        return result > 0;
    }

    public List<Destination> getAllDestinations() throws SQLException {
        String sql = "SELECT * FROM destination ORDER BY type, name";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        ResultSet rs = stmt.executeQuery();
        List<Destination> destinations = new ArrayList<>();

        while (rs.next()) {
            destinations.add(new Destination(rs.getInt("id"), 
                rs.getString("name"), rs.getString("type")));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return destinations;
    }

    public List<Destination> getDestinationsByType(String type) throws SQLException {
        String sql = "SELECT * FROM destination WHERE type = ? ORDER BY name";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, type);
        ResultSet rs = stmt.executeQuery();
        List<Destination> destinations = new ArrayList<>();

        while (rs.next()) {
            destinations.add(new Destination(rs.getInt("id"), 
                rs.getString("name"), rs.getString("type")));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return destinations;
    }

    public Destination getDestinationById(int id) throws SQLException {
        String sql = "SELECT * FROM destination WHERE id = ?";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        Destination dest = null;

        if (rs.next()) {
            dest = new Destination(rs.getInt("id"), rs.getString("name"), rs.getString("type"));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return dest;
    }
}
