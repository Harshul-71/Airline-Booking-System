package com.airline.dao;

import com.airline.models.Admin;
import com.airline.util.DB;
import java.sql.*;

public class AdminDAO {

    public Admin login(String username, String password) throws SQLException {
        String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, username);
        stmt.setString(2, password);

        ResultSet rs = stmt.executeQuery();
        Admin admin = null;

        if (rs.next()) {
            admin = new Admin(rs.getInt("id"), rs.getString("username"), rs.getString("password"));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return admin;
    }
}
