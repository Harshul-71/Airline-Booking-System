package com.airline.dao;

import com.airline.models.Customer;
import com.airline.util.DB;
import java.sql.*;
import java.util.*;

public class CustomerDAO {

    public boolean register(Customer customer) throws SQLException {
        String sql = "INSERT INTO customer (name, email, phone, password) VALUES (?, ?, ?, ?)";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, customer.getName());
        stmt.setString(2, customer.getEmail());
        stmt.setString(3, customer.getPhone());
        stmt.setString(4, customer.getPassword());

        int result = stmt.executeUpdate();

        stmt.close();
        DB.closeConnection(conn);
        return result > 0;
    }

    public Customer login(String email, String password) throws SQLException {
        String sql = "SELECT * FROM customer WHERE email = ? AND password = ?";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, email);
        stmt.setString(2, password);

        ResultSet rs = stmt.executeQuery();
        Customer customer = null;

        if (rs.next()) {
            customer = new Customer(rs.getInt("id"), rs.getString("name"), 
                rs.getString("email"), rs.getString("phone"), rs.getString("password"));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return customer;
    }

    public boolean isEmailExists(String email) throws SQLException {
        String sql = "SELECT COUNT(*) FROM customer WHERE email = ?";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();
        boolean exists = rs.next() && rs.getInt(1) > 0;

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return exists;
    }
}
