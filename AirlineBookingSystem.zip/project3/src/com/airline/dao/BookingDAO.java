package com.airline.dao;

import com.airline.models.Booking;
import com.airline.util.DB;
import java.sql.*;
import java.util.*;

public class BookingDAO {

    public boolean bookTicket(Booking booking) throws SQLException {
        String sql = "INSERT INTO booking (customer_id, flight_id, passenger_name, seat_no) VALUES (?, ?, ?, ?)";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setInt(1, booking.getCustomerId());
        stmt.setInt(2, booking.getFlightId());
        stmt.setString(3, booking.getPassengerName());
        stmt.setString(4, booking.getSeatNo());

        int result = stmt.executeUpdate();

        stmt.close();
        DB.closeConnection(conn);
        return result > 0;
    }

    public List<Booking> getCustomerBookings(int customerId) throws SQLException {
        String sql = "SELECT b.*, f.code as flight_code, d.name as destination_name, " +
                    "f.departure_time, f.base_price FROM booking b " +
                    "JOIN flight f ON b.flight_id = f.id " +
                    "JOIN destination d ON f.destination_id = d.id " +
                    "WHERE b.customer_id = ? ORDER BY b.booking_date DESC";

        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, customerId);

        ResultSet rs = stmt.executeQuery();
        List<Booking> bookings = new ArrayList<>();

        while (rs.next()) {
            Booking booking = new Booking();
            booking.setId(rs.getInt("id"));
            booking.setCustomerId(rs.getInt("customer_id"));
            booking.setFlightId(rs.getInt("flight_id"));
            booking.setPassengerName(rs.getString("passenger_name"));
            booking.setSeatNo(rs.getString("seat_no"));
            booking.setStatus(rs.getString("status"));
            booking.setBookingDate(rs.getTimestamp("booking_date").toLocalDateTime());
            booking.setFlightCode(rs.getString("flight_code"));
            booking.setDestinationName(rs.getString("destination_name"));
            booking.setDepartureTime(rs.getTimestamp("departure_time").toLocalDateTime());
            booking.setPrice(rs.getDouble("base_price"));
            bookings.add(booking);
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return bookings;
    }

    public int getCustomerBookingCount(int customerId, int flightId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM booking WHERE customer_id = ? AND flight_id = ? AND status = 'CONFIRMED'";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setInt(1, customerId);
        stmt.setInt(2, flightId);

        ResultSet rs = stmt.executeQuery();
        int count = rs.next() ? rs.getInt(1) : 0;

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return count;
    }

    public List<String> getUsedSeats(int flightId) throws SQLException {
        String sql = "SELECT seat_no FROM booking WHERE flight_id = ? AND status = 'CONFIRMED'";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setInt(1, flightId);
        ResultSet rs = stmt.executeQuery();
        List<String> usedSeats = new ArrayList<>();

        while (rs.next()) {
            usedSeats.add(rs.getString("seat_no"));
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return usedSeats;
    }

    public boolean cancelBooking(int bookingId, int customerId) throws SQLException {
        String sql = "UPDATE booking SET status = 'CANCELLED' WHERE id = ? AND customer_id = ?";
        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setInt(1, bookingId);
        stmt.setInt(2, customerId);

        int result = stmt.executeUpdate();

        stmt.close();
        DB.closeConnection(conn);
        return result > 0;
    }

    public List<Booking> getAllBookings() throws SQLException {
        String sql = "SELECT b.*, f.code as flight_code, d.name as destination_name, " +
                    "f.departure_time, f.base_price, c.name as customer_name FROM booking b " +
                    "JOIN flight f ON b.flight_id = f.id " +
                    "JOIN destination d ON f.destination_id = d.id " +
                    "JOIN customer c ON b.customer_id = c.id " +
                    "ORDER BY b.booking_date DESC";

        Connection conn = DB.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        ResultSet rs = stmt.executeQuery();
        List<Booking> bookings = new ArrayList<>();

        while (rs.next()) {
            Booking booking = new Booking();
            booking.setId(rs.getInt("id"));
            booking.setCustomerId(rs.getInt("customer_id"));
            booking.setFlightId(rs.getInt("flight_id"));
            booking.setPassengerName(rs.getString("passenger_name"));
            booking.setSeatNo(rs.getString("seat_no"));
            booking.setStatus(rs.getString("status"));
            booking.setBookingDate(rs.getTimestamp("booking_date").toLocalDateTime());
            booking.setFlightCode(rs.getString("flight_code"));
            booking.setDestinationName(rs.getString("destination_name"));
            booking.setDepartureTime(rs.getTimestamp("departure_time").toLocalDateTime());
            booking.setPrice(rs.getDouble("base_price"));
            bookings.add(booking);
        }

        rs.close();
        stmt.close();
        DB.closeConnection(conn);
        return bookings;
    }
}
