package com.airline.dsa;

/**
 * Circular Linked List implementation for DSA requirement
 * Last node points back to first node creating a circle
 */
public class CircularLinkedList<T> {
    private Node<T> tail;
    private int size;

    private static class Node<T> {
        T data;
        Node<T> next;

        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    public CircularLinkedList() {
        this.tail = null;
        this.size = 0;
    }

    // Add element at the end
    public void add(T data) {
        Node<T> newNode = new Node<>(data);

        if (tail == null) {
            tail = newNode;
            tail.next = tail; // Points to itself
        } else {
            newNode.next = tail.next; // Point to head
            tail.next = newNode;
            tail = newNode; // Update tail
        }
        size++;
    }

    // Add element at the beginning
    public void addFirst(T data) {
        Node<T> newNode = new Node<>(data);

        if (tail == null) {
            tail = newNode;
            tail.next = tail;
        } else {
            newNode.next = tail.next; // Point to current head
            tail.next = newNode; // Tail points to new head
        }
        size++;
    }

    // Remove element at given index
    public T remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }

        if (size == 1) {
            T data = tail.data;
            tail = null;
            size--;
            return data;
        }

        Node<T> current = tail.next; // Head
        Node<T> prev = tail;

        for (int i = 0; i < index; i++) {
            prev = current;
            current = current.next;
        }

        T data = current.data;
        prev.next = current.next;

        if (current == tail) {
            tail = prev;
        }

        size--;
        return data;
    }

    // Get element at given index
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }

        Node<T> current = tail.next; // Head
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    // Display the circular list
    public void display() {
        if (tail == null) {
            System.out.println("CircularLinkedList [0]: empty");
            return;
        }

        Node<T> current = tail.next; // Head
        System.out.print("CircularLinkedList [" + size + "]: ");

        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != tail.next);

        System.out.println("(back to head)");
    }

    // Search for an element
    public boolean contains(T data) {
        if (tail == null) return false;

        Node<T> current = tail.next; // Head
        do {
            if (current.data.equals(data)) {
                return true;
            }
            current = current.next;
        } while (current != tail.next);

        return false;
    }

    // Clear the list
    public void clear() {
        tail = null;
        size = 0;
    }
}
